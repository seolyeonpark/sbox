package com.example.soonbox_findpw.data;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.soonbox_findpw.DetailPost;
import com.example.soonbox_findpw.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Random;

public class SellerAdapter extends RecyclerView.Adapter<SellerAdapter.CustomViewHolder>{
    FirebaseDatabase mdatabase = FirebaseDatabase.getInstance();

    DatabaseReference  databaseRef;

    private ArrayList<Posts> arrayList;
    private Context context;
    private String mailid;


    public SellerAdapter(ArrayList<Posts> arrayList, Context context, String mailid) {
        this.arrayList = arrayList;
        this.context = context;
        this.mailid = mailid;
        this.databaseRef = mdatabase.getReference("users").child(mailid).child("postpw");

    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.purc_order_two, parent,false);
        CustomViewHolder holder = new CustomViewHolder(view);
        return holder;


       //파이어베이스 DB연동


    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, final int position) {
        Glide.with(holder.itemView)
                .load(arrayList.get(position).getPostimage())
                .into(holder.iv_thumbnail);
        holder.tv_product.setText(arrayList.get(position).getProduct());
        holder.tv_price.setText(String.valueOf(arrayList.get(position).getPrice()));
        holder.bv_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               //입금 완료 버튼/상대와 챗 -> 푸쉬
            }
        });
        holder.itemView.setTag(position);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, DetailPost.class);
                intent.putExtra("product",arrayList.get(position).getProduct());
                intent.putExtra("account",arrayList.get(position).getAccount());
                intent.putExtra("etc",arrayList.get(position).getEtc());
                intent.putExtra("name",arrayList.get(position).getName());
                intent.putExtra("postid",arrayList.get(position).getPostid());
                intent.putExtra("postimage",arrayList.get(position).getPostimage());
                intent.putExtra("price",arrayList.get(position).getPrice());
                intent.putExtra("username",arrayList.get(position).getSellername());
                intent.putExtra("forsale",arrayList.get(position).getForsale());
                intent.putExtra("myself", true);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return (arrayList != null ? arrayList.size() : 0);
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {
        ImageView iv_thumbnail;
        TextView tv_price;
        TextView tv_product;
        Button bv_button;
        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            this.iv_thumbnail = (ImageView) itemView.findViewById(R.id.iv_thumbnail);
            this.tv_price = (TextView) itemView.findViewById(R.id.tv_price);
            this.tv_product = (TextView) itemView.findViewById(R.id.tv_product);
            this.bv_button = (Button) itemView.findViewById(R.id.deposit_ok);
        }

    }

}